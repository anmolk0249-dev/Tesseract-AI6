# 🚀 Tesseract AI Chatbot

An AI-powered chatbot built with **Next.js**, **React**, **Framer Motion**, and **OpenAI GPT**.  
Customized with branding: **Tesseract AI** 🤖✨

---

## 📦 Project Structure
```
tesseract-ai/
 ├── components/AIChatbotWidget.tsx   # Chatbot UI
 ├── pages/index.tsx                  # Homepage rendering chatbot
 ├── pages/api/chat.ts                 # Secure backend API route
 ├── styles/globals.css               # Tailwind global styles
 ├── package.json                     # Dependencies & scripts
 ├── next.config.js                   # Next.js config
 ├── tailwind.config.js               # Tailwind setup
 ├── postcss.config.js                # PostCSS setup
 └── tsconfig.json                    # TypeScript config
```

---

## ⚡ Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Run locally
```bash
npm run dev
```
Visit 👉 `http://localhost:3000`

---

## 🌍 Deployment

### Deploy on Vercel (Recommended)
1. Push this repo to GitHub.  
2. Go to [Vercel](https://vercel.com) → Import project.  
3. Add environment variable in **Project Settings → Environment Variables**:
   ```
   OPENAI_API_KEY = your-secret-key-here
   ```
4. Click **Deploy** 🚀  
5. Your chatbot will be live at:  
   👉 `https://your-project.vercel.app`

### Custom Domain
- In Vercel → Project Settings → Domains → Add your custom domain.  
- Update your DNS records to point to Vercel.

---

## 🛡️ Security Note
- Never expose your API key in the frontend.  
- Always use the backend route (`/api/chat`) to keep keys safe.

---

## 🧑‍💻 Author
Built by **Vinit** – Builder of **Tesseract AI**.  
